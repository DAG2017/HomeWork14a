package HomeWork14;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Properties;

public class LoadProp {
    static Properties prop = new Properties();
    ;
    static String inputFileName = "TestDataConfig.properties";
    static String outputFileName = "NewTestDataConfig.properties";
    static String fileLocation = "C:\\Users\\admin\\Desktop\\SoftwareTesting\\CucumberMavenNopCommerce\\src\\test\\Resources\\";
    static FileInputStream input;
    static OutputStream output = null;


    public String getProperty(String key) {

        try {
            input = new FileInputStream(fileLocation + inputFileName);
            prop.load(input);
            input.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return prop.getProperty(key);
    }

    public void setProperty(String key, String value) {

        try {
            output = new FileOutputStream(fileLocation + outputFileName);
            prop.setProperty(key,value);
            prop.store(output, "save keys to NewTestDataConfig.properties");
            output.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
