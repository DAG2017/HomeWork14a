package PageObjects;

import HomeWork14.BasePage;
import HomeWork14.Utils;
import org.openqa.selenium.By;

public class ShoppingCartPage extends BasePage {

    private By _ProductNameOnShoppingCart1 = By.linkText("Custom T-Shirt");
    private By _ProductNameOnShoppingCart2 = By.linkText("Levi's 511 Jeans");
    private By _countryID = By.id("CountryId");
    private By _termsOfService = By.id("termsofservice");
    private By _checkOut = By.id("checkout");

    public void verifySelectedProductsAreInShoppingCartAndNavigateToCheckoutPage() {

        String expectedProductName1 = Utils.actualText(_ProductNameOnShoppingCart1);
        softAssert.assertEquals(loadProp.getProperty("actualProductName1"),expectedProductName1,"Wrong product1 selected");

        String expectedProductName2 = Utils.actualText(_ProductNameOnShoppingCart2);
        softAssert.assertEquals(loadProp.getProperty("actualProductName2"),expectedProductName2,"Wrong product2 selected");
        softAssert.assertAll();

        Utils.selectFromListByText(_countryID, loadProp.getProperty("country"));
        try{
            boolean flag = Utils.isAlertPresent();
            System.out.println("Alert = " +flag);
        }catch (Exception e){
            e.printStackTrace();
        }
        Utils.clickElement(_termsOfService);

        Utils.clickElement(_checkOut);
    }
}

